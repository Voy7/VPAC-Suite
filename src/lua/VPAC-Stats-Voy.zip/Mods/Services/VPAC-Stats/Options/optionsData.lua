cdata =
{
	STATS_OPTIONS_TITLE	= _('VPAC Stats Options'),
	STATS_ENABLE_LABEL = _('Enable VPAC Stats'),
	STATS_SERVER_LABEL = _('Is Dedicated Server'),
	STATS_KEY_LABEL = _('Secret Key / Password'),
	STATS_KEY_APPLY = _('Changes apply after restart'),
}